import os
nuke.pluginAddPath( '/Ahuge_Tools' )
# Nothing here currently